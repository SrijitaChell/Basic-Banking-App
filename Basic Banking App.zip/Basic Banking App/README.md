# Basic Banking App
This is a basic Banking App using which you can transfer money from one user to another, and the amount in their bank account is updated after each transaction. By default I have added 10 users in the database. The transaction history is record and displayed in the history page.\n
Video demo - https://www.youtube.com/watch?v=_uA-h_24PUg
![sparks](https://user-images.githubusercontent.com/57084282/125896126-16aa0651-c5fd-452a-9bd9-6a405b2f8cea.PNG)
